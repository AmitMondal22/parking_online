module.exports = { 
    secret: "PARKING_SECRET_ONLINE",
    ttl: 3600*24*30,
}
