// const mysql = require('mysql');

// const db = mysql.createPool({
//     connectionLimit: 10,
//     host: "localhost",
//     user: "myparking",
//     password: "5K#l661ll",
//     database: "myparking",
// });

// db.getConnection((err, connection) => {
//     if (err) console.log(err);
//     connection.release();
//     return;
// });

// module.exports = db;

const mysql = require('mysql');

const db = mysql.createPool({
    connectionLimit: 10,
    host: "localhost",
    user: "root",
    password: "",
    database: "parking_06022024",
});

db.getConnection((err, connection) => {
    if (err) console.log(err);
    connection.release();
    return;
});

module.exports = db;