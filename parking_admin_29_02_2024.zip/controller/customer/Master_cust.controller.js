const Joi = require("joi");
const dateFormat = require("dateformat");
const { db_Insert, db_Select } = require("../../model/Master.model");

const vehicle = async (req, res) => {
  try {
    page_data = {
      title: "blank",
      page_path: "vehicle/vehicle_add",
    };
    req.flash("success", "Blank Page");
    res.render("common/layouts/main", page_data);
  } catch (err) {
    res.render("/login");
  }
};

// View Create and Save a new Operator
const operator_add = async (req, res) => {
  try {
    page_data = {
      title: "blank",
      page_path: "operator/add",
    };
    req.flash("success", "Blank Page");
    res.render("common/layouts/main", page_data);
  } catch (err) {
    res.redirect("/login");
  }
};

// Create and Save a new Operator
const operator_add_post = async (req, res) => {
  try {
    const schema = Joi.object({
      operator_name: Joi.string().required(),
      password: Joi.string().required(),
      device_id: Joi.string().required(),
      user_id: Joi.required(),
      location_id: Joi.number().required(),
      c_password: Joi.string().valid(Joi.ref("password")).required().strict(),
    });
    const { error, value } = schema.validate(req.body, { abortEarly: false });
    if (error) {
      const errors = {};
      error.details.forEach((detail) => {
        errors[detail.context.key] = detail.message;
      });
      res.flash("error", "Invalid credentials");
      res.redirect("/operator/add");
    }
    //req.flash('error', "Bank Add Successful");
    req.flash("success", "operator created successfully");
    res.redirect("/operator/add");
    // console.log("===========================================================");
  } catch (err) {
    res.flash("error", "Error inserting data");
    res.redirect("/operator/add");
  }
};

const password_change = async (req, res) => {
  try {
    var custId = req.session.user.user_data.customer_id;
    let wher = `customer_id=${custId}`;
    var setting = await db_Select("*", "md_setting", wher, null);
    const page_data = {
      title: "password",
      page_path: "/settings/password",
      data: setting,
    };
    console.log(setting);
    res.render("common/layouts/main", page_data);
  } catch (error) {
    res.redirect("/login");
  }
};

const report_pwd = async (req, res) => {
  var data = req.body;
  //   console.log(data);
  var custId = req.session.user.user_data.customer_id;

  var select = "*",
    table_name = "md_setting",
    whr = `app_id = '${data.dev_id}' AND customer_id=${custId}`,
    order = null;
  var pwd_data = await db_Select(select, table_name, whr, order);
  res.send(pwd_data);
};

const save_report_password = async (req, res) => {
  try {
    var data = req.body;
    // console.log(data);

    const userData = req.user;
    const datetime = dateFormat(new Date(), "yyyy-mm-dd");

    let fields = `password = ${data.pwd},modified_by=${data.cust_id},updated_at='${datetime}'`,
      where = `customer_id='${data.cust_id}' AND app_id='${data.app_id}' AND setting_id='${data.set_id}'`;
    let res_dt = await db_Insert("md_setting", fields, null, where, 1);
    console.log(res_dt);
    res.redirect("/password");
  } catch (error) {
    console.log(error);
    res.send({ suc: 0, msg: error });
  }
};

module.exports = {
  vehicle,
  operator_add,
  operator_add_post,
  password_change,
  save_report_password,
  report_pwd,
};
